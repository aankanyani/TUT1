﻿using test4.Models;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.Mvc;
using System;
using System.Collections.Generic;
using System.Net;
using test4.Models.AdoNet;
using System.Web.Helpers;

namespace test4.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }
        // POST: /Delete/25
        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(int id)
        {
            var _userDataAction = new DeleteUserData();
            var response = _userDataAction.DeleteUser(id);
            return RedirectToAction("About");
        }

        [HttpPost]
        public ActionResult Index(SaveDataRequest player)
        {
            var _userDataAction = new InsertUserData();
            var response = _userDataAction.InsertUser(player);
            return View(response);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult CreateNow([Bind(Include = " date, status,description,item, itemCategory, quantity, total,UserID")] TestContactInformationData TestContactInformationData)
        {

            var _userDataAction = new InsertCustomerInformationData();
            TestContactInformationData.UserID = Session["userId"].ToString();
            var response = _userDataAction.InsertCustomerAddress(TestContactInformationData);
            return View("Index");
        }
        // POST: /Edit/25
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult EditAddress([Bind(Include = "orderID,date,status,description,item,itemCategory,quantity,total")] ViewAddress ViewAddress)
        {
            var _userDataAction = new Editaddr();
            var response = _userDataAction.Editaddresses(ViewAddress);
            return RedirectToAction("About");
        }

        public ActionResult Export()
        {
            var _userDataAction = new ViewExportData();
            var response = _userDataAction.viewexport();
            return View(response);
        }

        public void PrintExcel()
        {
            var _userDataAction = new ViewExportData();
            var response = _userDataAction.viewexport();
            WebGrid grid = new WebGrid(source: response, canPage: false, canSort: false);
            string gridData = grid.GetHtml(
            columns: grid.Columns(
                            grid.Column("date"),
                            grid.Column("status"),
                            grid.Column("description"),
                            grid.Column("item"),
                            grid.Column("itemCategory"),
                            grid.Column("quantity"),
                            grid.Column("total")
                            )).ToString();
            Response.ClearContent();
            Response.AddHeader("content-disposition", "attachment; filename=UserData.xls");
            Response.ContentType = "application/excel";
            Response.Write(gridData);
            Response.End();
        }


        // GET: /Edit/25
        public ActionResult Edit(int id)
        {
            var _userDataAction = new DeleteEditUserData();
            var response = _userDataAction.EditDeleteUser(id);
            return View(response);
        }
        
        public ActionResult EditAddress(int id)
        {
            var _userDataAction = new EditAddressData();
            var response = _userDataAction.EditAddrUser(id);
            return View(response);
        }

        public ActionResult ViewAddr(int id)
        {
            var _userDataAction = new ViewAddressData();
            var response = _userDataAction.viewAddressDet(id);
            return View(response);
        }


        // POST: /Edit/25
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "id,name,surname")] ViewData ViewData)
        {
            var _userDataAction = new EditUserData();
            var response = _userDataAction.EditUser(ViewData);
            return RedirectToAction("About");
        }
  
        public ActionResult Create(int id)
        {
            Session["userId"] = id;
            return View();
        }

        

        public ActionResult About()
        {
            var _userDataAction = new ViewUserData();
            var response = _userDataAction.ViewUser();
            return View(response);
        }



        // GET: /Delete/25
        public ActionResult Delete(int id)
        {
            var _userDataAction = new DeleteAddress();
            var response = _userDataAction.Deleteaddress(id);
            return View(response);
        }


    }
}