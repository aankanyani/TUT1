﻿namespace test4.Models
{
    public class SaveDataRequest
    {
        /// <summary>
        /// Gets or sets Name.
        /// </summary>
        public string name { get; set; }

        /// <summary>
        /// Gets or sets Surname.
        /// </summary>
        public string surname { get; set; }

        /// <summary>
        /// Gets or sets gender.
        /// </summary>
        public string gender { get; set; }

        /// <summary>
        /// Gets or sets IDNumber.
        /// </summary>
        public string IDNumber { get; set; }
    }
}