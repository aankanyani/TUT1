﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace test4.Models.AdoNet
{
    public class InsertCustomerInformationData
    {
        private string _connectionString;
        public InsertCustomerInformationData()
        {
            _connectionString = ConfigurationManager.ConnectionStrings["Constring"].ConnectionString;
        }
      
        public TestContactInformationData InsertCustomerAddress(TestContactInformationData user)
        {
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                var query = "INSERT INTO TestOrders( date, status, description, item, itemCategory, quantity, total, UserID) VALUES( @date, @status, @description, @item, @itemCategory, @quantity, @total, @UserID)";
                using (SqlCommand cmd = new SqlCommand(query))
                {
                    cmd.Connection = con;
                    con.Open();
                    cmd.Parameters.AddWithValue("@date", user.date);
                    cmd.Parameters.AddWithValue("@status", user.status);
                    cmd.Parameters.AddWithValue("@description", user.description);
                    cmd.Parameters.AddWithValue("@item", user.item);
                    cmd.Parameters.AddWithValue("@itemCategory", user.itemCategory);
                    cmd.Parameters.AddWithValue("@quantity", user.quantity);
                    cmd.Parameters.AddWithValue("@total", user.total);
                    cmd.Parameters.AddWithValue("@UserID", user.UserID);
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
                return user;
            }
        }
    }
}