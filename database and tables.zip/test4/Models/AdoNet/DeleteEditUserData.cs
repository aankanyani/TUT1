﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace test4.Models.AdoNet
{
    public class DeleteEditUserData
    {
        private string _connectionString;
        public DeleteEditUserData()
        {
            _connectionString = ConfigurationManager.ConnectionStrings["Constring"].ConnectionString;
        }
        public ViewData EditDeleteUser(int id)
        {
            var response = new ViewData();
            using (SqlConnection con = new SqlConnection(_connectionString))
            {

                var query = "SELECT * FROM TestNetAmu WHERE id = '" + id + "'";
                using (SqlCommand cmd = new SqlCommand(query))
                {

                    cmd.Connection = con;
                    con.Open();

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.HasRows)
                        {
                            while (reader.Read())
                            {
                                response.id = reader[0].ToString();
                                response.name = reader[1].ToString();
                                response.surname = reader[2].ToString();
                                response.gender = reader[3].ToString();
                                response.IDNumber = reader[4].ToString();
                            }
                        }
                    }
                }

            }
            return response;
        }
    }
}