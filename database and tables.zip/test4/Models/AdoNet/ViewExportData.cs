﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace test4.Models.AdoNet
{
    public class ViewExportData
    {
        private string _connectionString;
        public ViewExportData()
        {
            _connectionString = ConfigurationManager.ConnectionStrings["Constring"].ConnectionString;
        }


        public List<ViewExport> viewexport()
        {
            try
            {
                var response = new List<ViewExport>();
                using (SqlConnection con = new SqlConnection(_connectionString))
                {
                    var query = "select u.name, u.surname, u.gender, u.IDNumber, c.date, c.status, c.description, c.item, c.itemCategory, c.quantity, c.total from TestNetAmu u, TestOrders c where u.id = c.UserID";
                    using (SqlCommand cmd = new SqlCommand(query))
                    {
                        cmd.Connection = con;
                        con.Open();

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                while (reader.Read())
                                {
                                    response.Add(new ViewExport
                                    {
                                        name = reader[0].ToString(),
                                        surname = reader[1].ToString(),
                                        gender = reader[2].ToString(),
                                        IDNumber = reader[3].ToString(),
                                        date = reader[4].ToString(),
                                        status = reader[5].ToString(),
                                        description = reader[6].ToString(),
                                        item = reader[7].ToString(),
                                        itemCategory = reader[8].ToString(),
                                        quantity = reader[9].ToString(),
                                        total = reader[10].ToString()
                                    });
                                }
                            }
                        }

                    }

                }

                return response;

            }
            catch
            {

                throw;
            }
        }
    }
}