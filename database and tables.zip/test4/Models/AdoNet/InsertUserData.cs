﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace test4.Models.AdoNet
{
    public class InsertUserData
    {
        private string _connectionString;
        public InsertUserData()
        {
            _connectionString = ConfigurationManager.ConnectionStrings["Constring"].ConnectionString;
        }
      
        public SaveDataRequest InsertUser(SaveDataRequest user)
        {
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                var query = "INSERT INTO TestNetAmu(name, surname, gender, IDNumber) VALUES(@name, @surname, @gender, @IDNumber)";
                using (SqlCommand cmd = new SqlCommand(query))
                {
                    cmd.Connection = con;
                    con.Open();
                    cmd.Parameters.AddWithValue("@Name", user.name);
                    cmd.Parameters.AddWithValue("@Surname", user.surname);
                    cmd.Parameters.AddWithValue("@gender", user.gender);
                    cmd.Parameters.AddWithValue("@IDNumber", user.IDNumber);
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
                return user;
            }
        }
    }
}