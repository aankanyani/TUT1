﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace test4.Models.AdoNet
{
    public class DeleteUserData
    {
        private string _connectionString;
        public DeleteUserData()
        {
            _connectionString = ConfigurationManager.ConnectionStrings["Constring"].ConnectionString;
        }
        public bool DeleteUser(int id)
        {
            using (SqlConnection con = new SqlConnection(_connectionString))
            {
                var query = "DELETE FROM TestOrders WHERE orderID = '" + id + "'";
                using (SqlCommand cmd = new SqlCommand(query))
                {
                    cmd.Connection = con;
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();

                }

            }
            return true;
        }
    }
}