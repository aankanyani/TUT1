﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using test4.Controllers;
using test4.Models;
using test4.Models.AdoNet;

namespace UnitTestProject2
{
    [TestClass]
    public class UnitTest1
    {
        private HomeController _HomeController;
        private InsertUserData _userData;
        private ViewUserData _viewData;
        private DeleteUserData _deleteData;
        private EditUserData _editData;
        private DeleteEditUserData _deleteeditUserData;
        public UnitTest1()
        {
            _HomeController = new HomeController();
            _userData = new InsertUserData();
            _viewData = new ViewUserData();
            _deleteData = new DeleteUserData();
            _editData = new EditUserData();
            _deleteeditUserData = new DeleteEditUserData();
        } 
        [TestMethod]
        public void Index()
        {
            SaveDataRequest Request = new SaveDataRequest
            {
                name = "Tester",
                surname = "testing"
            };

            var actual = _HomeController.Index(Request);
            Assert.IsNotNull(actual);
        }
        [TestMethod]
        public void DeleteEditUser()
        {
            int id = 1;

            var actual = _deleteeditUserData.EditDeleteUser(id);
            Assert.IsNotNull(actual);
        }

        [TestMethod]
        public void DeleteUser()
        {
            int id = 1;
            var response = _deleteData.DeleteUser(id);
            Assert.IsTrue(response);
        }

        [TestMethod]
        public void EditUser()
        {
            ViewData Request = new ViewData
            {
                name = "sheilla",
                id = "4",
                surname = "nkanyani"
            };
            var response = _editData.EditUser(Request);
            Assert.IsNotNull(response);
        }

        [TestMethod]
        public void InsertUser()
        {
            SaveDataRequest Request = new SaveDataRequest
            {
                name = "Tester",
                surname = "testing"
            };

            var response = _userData.InsertUser(Request);
            Assert.IsTrue(response);
        }

        [TestMethod]
        public void ViewUser()
        {
            var response = _viewData.ViewUser();
            Assert.IsNotNull(response);
        }
    }
}
